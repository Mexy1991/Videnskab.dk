# <a href="http://www.videnskab.dk">Videnskab.dk</a>

The app is created for Videnskab.dk and shows a WebView of the site.

# License
The content on Videnskab.dk is protected by <a href="videnskab.dk/side/rettigheder" target="_blank">copyright</a>. The source code, however, is licenced under  <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.

<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a>

# Author
Josephine Søgaard Andersen.

Email: josephine.s.andersen@gmail.com

Twitter: http://twitter.com/sogaardandersen

GitHub: https://github.com/mexy1991

# Thanks
Thanks to <a href="https://www.youtube.com/watch?v=0IJauzoeJt4">codesolutionz</a> for a video tutorial of the initial setup.
